# ScriptLab (Vite + React)

1. Commit todos os arquivos no repositório `roblox-coder-ai`.
2. Vá ao Vercel → Add New → Import Project → Conecte ao repositório.
3. **Framework Preset:** Other (ou deixe automático)
4. **Build Command:** `npm run build`
5. **Output Directory:** `dist`
6. Deploy

Se a Vercel detectar Vite automaticamente, apenas clique Deploy.

Navegador recomendado: Chrome ou Edge (suporte WebGPU para modelo local).
